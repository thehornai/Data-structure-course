#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	
	int numbers[10] = { 5,10,15,20,25,30,35,40,45,50};
	int search;
	
	for(int i=0;i<10;i++){
		cout<<numbers[i]<<" ";
	}
	cout<<endl;
	cin>>search;
	
	for(int i=0;i<10;i++){
		if (numbers[i] == search){
			cout<<"number found at location "<<i<<endl;
		}

	}
	
	
	
	
	return 0;
}
