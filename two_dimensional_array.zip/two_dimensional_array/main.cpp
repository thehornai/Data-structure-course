#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

using namespace std;

int main(int argc, char** argv) {
	
	int board[5][3] = { {2,3,5},
						{1,5,0},
						{2,5,6},
						{8,9,7},
						{10,2,3}
						};
						
						
	//cout<<board[2][2];
	
	for(int i=0;i<3;i++){
		cout<<board[3][i]<<", ";
	}
	cout<<"\n\n";
	for(int i=0;i<3;i++){
		cout<<board[i][0]<<"\n";
	}
	
	for(int i=0;i<5;i++){
		cout<<"\n";
		for(int j=0;j<3;j++){
			cout<<board[i][j]<<", ";
		}
	}
	
	
						
	return 0;
}
