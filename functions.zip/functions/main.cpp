#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

using namespace std;

//function declaration
int addition(int, int);
double substraction(int, double);

int main(int argc, char** argv) {
	
	int result;
	double r;
	
	
	//function call
	result = addition(3,5);
	cout<<result;
	
	result = addition(845245,1078547);
	cout<<result;
	
	
	
	//function call
	r = substraction(7,4.5);
	cout<<r;
	
	return 0;
}


//function definition
int addition(int x,int y){
	cout<<"x = "<<x<<endl;
	cout<<"y = "<<y<<endl;
	
	return (x+y);
}

//function definition
double substraction(int x, double y){
	cout<<"\n\nx = "<<x<<endl;
	cout<<"y = "<<y<<endl;
	
	return (x-y);
}



