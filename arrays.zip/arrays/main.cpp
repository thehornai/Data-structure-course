#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

using namespace std;

int main(int argc, char** argv) {
	
	
	
	int a[9] = {1, 4 ,17 ,3 ,90 ,79 ,4 ,6 , 81};
	double sum = 0.0;
	
	
	/*
		cout <<"the value of a[0] is "<<a[0]<<endl;
		cout <<"the value of a[8] is "<<a[8]<<endl;
		
		cout <<"the value of a[5] is "<<a[5]<<endl;
		a[5] = 60;
		cout <<"the value of a[5] is "<<a[5]<<endl;
		
		
		cout <<"the value of a[10] is "<<a[10]<<endl;
		a[10] = 50;
		cout <<"the value of a[10] is "<<a[10]<<endl;
		*/
		
		/*
		if (a[3] == 4){
			cout<<"it is correct!"<<endl;
		}
		else {
			cout<<"it is not correct!"<<endl;
		}
		*/
		
		for(int i=0; i < 9; i++){
		
			cout<<"the value of a["<<i<<"] is "<<a[i]<<endl;
			sum = sum + a[i];
			
		}
		/*
		cout<<"\n\n";
		
		for(int i=0; i < 9; i++){
		
			cout<<"the value of a["<<i<<"] is "<<a[i]<<endl;
		}
		*/
	
	cout<<sum<<endl;

	
	
	
	

	return 0;
}
