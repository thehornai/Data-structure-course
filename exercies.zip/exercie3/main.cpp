#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int main(int argc, char** argv) {
	char ch[5];
	
	cout<<"Enter characters"<<endl;
	for(int i=0;i<5;i++){
		cin>>ch[i];
	}
	
	cout<<"Concatinated characters: \n\n";
	for(int i=0;i<5;i++){
		cout<<ch[i];
	}
	return 0;
}
