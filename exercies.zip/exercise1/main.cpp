#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
int main(int argc, char** argv) {
	
	double marks[4];
	double sum=0.0;
	int i;
	
	cout<<"This program stores the marks of four student only"<<endl;
	cout<<"=======================================================\n\n\n";
	
	for(i=0; i<4; i++){
		cout<<"Enter score of sub "<<i+1<<endl;
		cin>>marks[i];
		sum += marks[i];
	}

	
	
	cout<<"\n\n";
	cout<<"id\t\tname\t\tsub1\t\tsub2\t\tsub3\t\tsub4\t\ttotal\t\taverage"<<endl;
	cout<<"101\t\tmohamed\t\t";
	
	for (i=0;i<4; i++){
		cout<<marks[i]<<"\t\t";
	}
	cout<<sum<<"\t\t";
	cout<<sum/4;
	
	
	return 0;
}
