#include <iostream>
#include <string>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

using namespace std;

int main(int argc, char** argv) {
	string students[10];
	
	
	
	cout<<"Registeration of students:"<<endl;
	cout<<"============================\n\n";
	
	for (int i=0;i<10;i++){
		cout<<"Enter studetn "<<i+1<<endl;
		cin>>students[i];
	}
	
	cout<<"\n\nList of the students:"<<endl;
	cout<<"===============================\n";
	for(int j=0;j<10;j++){
		cout<<j<<"\t"<<students[j]<<endl;
	}
	int id;
	while(id != -1){
		
	cout<<"\n\nEnter numbers between (-1 to 9):"<<endl;
	if(id >= -1 && id <= 9){
	cin>>id;
	cout<<"the student that you are searching is : "<<students[id]<<endl;
	cout<<"Enter -1 to exit"<<endl;
	}
	
	}
	
	
	
	return 0;
}
